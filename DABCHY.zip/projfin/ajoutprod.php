<?php
include "acessdabchy.php";
session_start();


if (!empty($_POST)){
    
    if (ajoutprod($_POST)){
        header('location:listeprod.php');
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
        
</header>
<div class="container">
<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                <div class="form-group">
                    <label for="nom">Nom Du Produit :</label>
                    <input type="text" id="nom" name="nom" required>
                </div>
                <div class="form-group">
                    <label for="description">Description :</label>
                    <input type="text" id="description" name="description" required>
                </div>
                <div class="form-group">
                    <label for="prix">Prix :</label>
                    <input  id="prix" name="prix" required>
                </div>
                <div class="form-group">
                    <label for="image">Image :</label>
                    <input type="text" id="image" name="image" required>
                </div>
                <div class="form-group">
                    <label for="video">Video :</label>
                    <input type="text" id="video" name="video" required>
                </div>
                <div class="form-group">
                    <label for="stock">Stock :</label>
                    <input  id="qte" name="qte" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Ajouter</button>
                    
                </div>

            </form>    

</div>




</body>
</html>            