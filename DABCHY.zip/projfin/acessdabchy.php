<?php


function getprod(){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
$requette="SELECT * FROM produits";
$resultat=$db->query($requette);
$produits=$resultat->fetchAll();
return $produits;
 


}


function getprodbyid($id) {
     try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
  $requette="SELECT * FROM produits WHERE id_prod=$id";
  $resultat=$db->query($requette);
  $produit=$resultat->fetch();
  return $produit;
}
 
 function addvis($data){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
    $requette="INSERT INTO visiteur (nom,prenom,email,tel,mdp) VALUES('".$data['nom']."','".$data['prenom']."','".$data['email']."','".$data['tel']."','".$data['mdp']."') ";
    $resultat= $db->exec($requette);
    if ($resultat){
        return true;
    }else{
       return false; 
    }
}
function connectvis($data){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
    $email = $db->quote($data['email']);
    $mdp = $db->quote($data['mdp']);
    $requette=" SELECT * FROM visiteur WHERE email=$email AND mdp=$mdp";
    $resultat= $db->query($requette);
    $user= $resultat->fetch();
    return $user;
}
function connectadmin($data){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
    $email = $db->quote($data['email']);
    $mdp = $db->quote($data['mdp']);
    $requette=" SELECT * FROM admin WHERE email=$email AND mdp=$mdp";
    $resultat= $db->query($requette);
    $user= $resultat->fetch();
    return $user;

} 


function ajoutprod($data){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }

    
    $requette= "INSERT INTO produits(nom,description,prix,image,video) VALUES('".$data['nom']."','".$data['description']."','".$data['prix']."','".$data['image']."','".$data['video']."') ";

    $resultat= $db->exec($requette);

    
    if ($resultat){
         $id=$db-> lastInsertId();
        $requette2="INSERT INTO stock (produit,qte) VALUES('$id','".$data['qte']."')" ;
        if($db->exec($requette2)){
            return true;
            }else{
             return false;
            }
       
     }}

function supprod($id){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }


$requette="DELETE FROM produits WHERE id_prod='$id' ";
$resultat=$db->query($requette);
if ($resultat){
    return true;
}else{
   return false; 
}
}

function getallvis(){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
$requette="SELECT * FROM visiteur";
$resultat=$db->query($requette);
$visiteurs=$resultat->fetchAll();
return $visiteurs;
 


}
function suppvis($id){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }


$requette="DELETE FROM visiteur WHERE id_vis='$id' ";
$resultat=$db->query($requette);
if ($resultat){
    return true;
}else{
   return false; 
}
}

function getstock(){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
$requette="SELECT nom,id,qte FROM produits,stock WHERE produits.id_prod=stock.produit  ";
$resultat=$db->query($requette);
$stocks=$resultat->fetchAll();
return $stocks;
 


}
function getallpan(){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
$requette="SELECT v.nom,v.prenom ,v.tel,p.total,p.etat,p.date,p.id FROM panier p,visiteur v WHERE p.visiteur=v.id_vis ";
$resultat=$db->query($requette);
$paniers=$resultat->fetchAll();
return $paniers;


}
function getallcomm($id){
    try {
        $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die('Erreur : ' . $e->getMessage());
    }


    $requete = "SELECT p.nom, c.qte, c.total, c.date FROM commandes c INNER JOIN produits p ON c.produit = p.id_prod WHERE c.panier = :id";
    $stmt = $db->prepare($requete);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    
    $commandes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $commandes;
}


function getalladmin(){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
$requette="SELECT * FROM admin ";
$resultat=$db->query($requette);
$admins=$resultat->fetchAll();
return $admins;
 


}


function suppadmin($id){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }


$requette="DELETE FROM admin WHERE id_admin='$id' ";
$resultat=$db->query($requette);
if ($resultat){
    return true;
}else{
   return false; 
}
}

function ajoutadmin($data){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
    $requette="INSERT INTO admin (nom,prenom,email,tel,mdp) VALUES('".$data['nom']."','".$data['prenom']."','".$data['email']."','".$data['tel']."','".$data['mdp']."') ";
    $resultat= $db->exec($requette);
    if ($resultat){
        return true;
    }else{
       return false; 
    }
}

function getdata(){
    try
    {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');
    
    }
    catch (Exception $e)
    {
    die('Erreur : ' . $e->getMessage());
    }
    $data=array();

    $requette1="SELECT count(*) FROM produits ";
    $resultat1=$db->query($requette1);
    $nbprod=$resultat1->fetch();
    $requette2="SELECT count(*) FROM visiteur ";
    $resultat2=$db->query($requette2);
    $nbcl=$resultat2->fetch();
    $requette3="SELECT count(*) FROM commandes ";
    $resultat3=$db->query($requette3);
    $nbcomm=$resultat3->fetch();
    $data["produits"]=$nbprod[0];
    $data["clients"]=$nbcl[0];
    $data["commandes"]=$nbcomm[0];

    return $data;

}
?>