<?php

session_start();
if(!isset($_SESSION['nom'])){
    header('location:connexion.php');
    exit();
}

include "acessdabchy.php";
try
{
$db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');

}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}

$total=$_SESSION['panier'][1];
$commandes=array();
if(isset($_SESSION['panier']) && count($_SESSION['panier'][3]) > 0) {
    $commandes = $_SESSION['panier'][3];
    $_SESSION['order_validated'] = true;


} 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dabchy - Accueil</title>
    <link rel="stylesheet" href="style.css">
    <style> .block {
    margin-left:100px ;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    
}

        /* General table styles */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th,
        .table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        /* Header row styles */
        .table thead th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        /* Alternate row background color */
        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

       

        .btn:hover {
            background-color: red;
        }
    </style>
</head>
<body>
    <header>
        <h1>Dabchy</h1>
        <nav>
            <ul>
                <li><a href="home.php">Accueil</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="connexion.php">Connexion</a></li>
                <li><a href="compte.php">Compte</a></li>
                <li><a href="panier.php">Panier</a></li>
            </ul>
        </nav>
    </header>
   
    <div class="container">
        <h1>Votre Panier</h1>
        <div>
            <h2>Liste Des Achats</h2>
        </div>

        <div >
            <table class="table">
                <thead>
                    <tr class="">
                        <th scope="col">#</th>
                        <th scope="col">Produit</th>
                        <th scope="col">Quantite</th>
                        <th scope="col">Total</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach($commandes as $index => $commande) {
                        print '<tr>
                                <th scope="row">'.($index+1).'</th>
                                <td>'.$commande[4].'</td>
                                <td>'.$commande[0].'</td>
                                <td>'.$commande[1].' DT</td>
                                <td><a href="supp.php?id='.$index.'" class="btn">Supprimer</a></td>
                               </tr>';
                    }
                    ?>
                </tbody>
            </table>       
        </div>  
    </div>
   <div class="block">
    <h1>Total des achats=<?php echo $total;  ?> DT</h1>
    <a href="valider.php" class="btn" id="validerbtn">Valider</a> 
    <br>
    
    <a href="produits.php" class="btn">Retour</a>
   </div>
   <br>
   <br>
   <footer class="autrepage">

<div class="container2">
    <div class="grid-container">
        <div class="grid-item">
            <h2>Besoin d'aide</h2>
            <a href="contact.php">Envoyer un email</a>
        </div>

        <div class="grid-item">
            <h2>Cela peut t'intéresser</h2>
            <a href="produits.php">Robes</a>
            <a href="produits.php">Vestes</a>
            <a href="produits.php">Manteaux</a>
            <a href="produits.php">Pulls et gilets</a>
            <a href="produits.php">Baggy jeans</a>
            <a href="produits.php">Pantalons</a>
            <a href="produits.php">Jupes et Shorts</a>
        </div>

        <div class="grid-item">
            <h2>Réseaux sociaux</h2>
            <a href="https://www.facebook.com" target="_blank"><img  src="facebook.png" label="Facebook">Facebook</a>
            <a href="https://www.instagram.com" target="_blank"><img  src="instagram.png" label="Instagram">Instagram</a>
        </div>
    </div>
</div>
</footer>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("validerbtn").addEventListener("click", function(event) {
            <?php if(isset($_SESSION['order_validated']) && $_SESSION['order_validated'] == true): ?>

                alert('VOTRE COMMANDE A ETE VALIDE AVEC SUCCES');
                <?php unset($_SESSION['order_validated']); ?>
            <?php endif; ?>
        });
    });
</script>

  



</body>
</html>