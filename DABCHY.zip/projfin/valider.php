<?php
session_start();
include "acessdabchy.php";
try
{
$db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');

}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}
$visiteur=$_SESSION['id_vis'];
$total=$_SESSION['panier'][1];
$date = date("Y-m-d");
//creation panier
$requette_panier="INSERT INTO panier (visiteur,total,date) VALUES ('$visiteur','$total','$date')";
$resultat=$db->exec($requette_panier);
$panier_id=$db->lastInsertId();
$commandes=$_SESSION['panier'][3];
foreach($commandes as $commande){
  $qte=$commande[0];
  $total=$commande[1];
  $id=$commande[3];
  $requette="INSERT INTO commandes (produit,qte,total,panier,date) VALUES ('$id','$qte','$total','$panier_id','$date') ";
  $resultat=$db->exec($requette);  
}

$_SESSION['panier']=null;
header('location:home.php');





?>