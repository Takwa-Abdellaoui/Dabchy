<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8', 'root', '');
    } catch (Exception $e) {
        die('Erreur : ' . $e->getMessage());
    }

    $id = $_GET['id'];
    // Retrieve data from POST request
    $nom = $_POST['nom'];
    $description = $_POST['description'];
    $prix = $_POST['prix'];
    $image = $_POST['image'];
    $video = $_POST['video'];

    // Prepare SQL statement to update product
    $requete = "UPDATE produits SET nom=:nom, description=:description, prix=:prix, image=:image, video=:video WHERE id_prod=:id";
    $statement = $db->prepare($requete);
    
    // Bind parameters
    $statement->bindParam(':nom', $nom);
    $statement->bindParam(':description', $description);
    $statement->bindParam(':prix', $prix);
    $statement->bindParam(':image', $image);
    $statement->bindParam(':video', $video);
    $statement->bindParam(':id', $id);
    
    // Execute the statement
    $resultat = $statement->execute();

    if ($resultat) {
        // Redirect to the product list page after successful update
        header('Location: listeprod.php');
        exit;
    } else {
        // Handle errors if the update fails
        echo "Erreur lors de la mise à jour du produit.";
    }
}

// If the form is not submitted, retrieve the product data and populate the form fields
try {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

$id = $_GET['id'];
// Retrieve product data from the database
$statement = $db->prepare("SELECT * FROM produits WHERE id_prod=:id");
$statement->execute(array(':id' => $id));
$produit = $statement->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification Produit</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom'] . " " . $_SESSION['prenom']; ?></h4>
    </header>
    <div class="container">
        <h1>Modification</h1>
        <form action="<?= $_SERVER['PHP_SELF'] . '?id=' . $id ?>" method="post">
            <div class="form-group">
                <label for="nom">Nouveau Nom Du Produit :</label>
                <input type="text" id="nom" name="nom" value="<?= $produit['nom'] ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description :</label>
                <input type="text" id="description" name="description" value="<?= $produit['description'] ?>" required>
            </div>
            <div class="form-group">
                <label for="prix">Prix :</label>
                <input type="text" id="prix" name="prix" value="<?= $produit['prix'] ?>" required>
            </div>
            <div class="form-group">
                <label for="image">Image :</label>
                <input type="text" id="image" name="image" value="<?= $produit['image'] ?>" required>
            </div>
            <div class="form-group">
                <label for="video">Video :</label>
                <input type="text" id="video" name="video" value="<?= $produit['video'] ?>" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn">Modifier</button>
                <a href="listeprod.php" class="btn">Retour</a>
            </div>
        </form>
    </div>
</body>

</html>