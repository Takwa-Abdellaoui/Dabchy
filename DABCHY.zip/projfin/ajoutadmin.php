<?php
include "acessdabchy.php";
session_start();


if (!empty($_POST)){
    
    if (ajoutadmin($_POST)){     
        header('location:listeadmin.php');
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
        
</header>
<div class="container">
<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                <div class="form-group">
                    <label for="nom">Nom :</label>
                    <input type="text" id="nom" name="nom" required>
                </div>
                <div class="form-group">
                    <label for="prenom">Prenom :</label>
                    <input type="text" id="prenom" name="prenom" required>
                </div>
                <div class="form-group">
                    <label for="email">Email :</label>
                    <input  id="emai" name="email" required>
                </div>
                <div class="form-group">
                    <label for="tel">Tel :</label>
                    <input type="text" id="tel" name="tel" required>
                </div>
                <div class="form-group">
                    <label for="mot_de_passe">Mot de passe :</label>
                    <input type="password" id="mdp" name="mdp" required>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn">Ajouter</button>
                </div>
            </form>    

</div>




</body>
</html>            