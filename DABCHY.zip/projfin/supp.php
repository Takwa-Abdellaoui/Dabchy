<?php
session_start();
$id=$_GET['id'];

$totalsupp=$_SESSION['panier'][3][$id][1];
$_SESSION['panier'][1] -= $totalsupp;
unset($_SESSION['panier'][3][$id]);
header("location:panier.php");




?>