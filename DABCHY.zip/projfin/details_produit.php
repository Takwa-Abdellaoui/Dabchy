<?php
session_start();
include "acessdabchy.php";
$is_logged_in = false;
if(isset($_SESSION['nom'])) {
    $is_logged_in = true;
}
if (isset($_GET['id'])){
    $produit= getprodbyid($_GET['id']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du produit</title>
    <link rel="stylesheet" href="style.css">
    <style> .a{
        display: flex;
        align-items: center;
        justify-content: center;
        
      }
      .a .b .output{
        border-top-left-radius: 5px;
        border-top-right-radius: 5px;
        font-size: 22px;
        color: grey;
        text-align: center;
        padding: 15px;
        cursor: pointer;


      }
      .a .b .lists{
        background: #fff;
        box-shadow :0px 5px 10px black;
        padding: 5px 10px;
        border-top: 1px solid black;
        width: 400px;
        border-bottom-left-radius: 5px;
        border-bottom-right-radius: 5px;
        transform-style: preserve-3d;
        transform-origin: top;
        transform: rotateX(-90deg);
        opacity: 0;

      }
      .a .b:hover .lists,
      .a .b .lists:hover,
      .a .b .output:focus .lists,
      .a .b .output:focus-within .lists{
        transform: rotateX(0);
        opacity: 1;
        flex-direction: c;

      }</style>
    
</head>
<body>
    <header>
        <h1>Dabchy</h1>
        <nav>
            <ul>
                <li><a href="home.php">Accueil</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="connexion.php">Connexion</a></li>
                <li><a href="compte.php">Compte</a></li>
                <li><a href="panier.php">Panier</a></li>
            </ul>
        </nav>
    </header>

    <section class="details-produit">
          
    <div class="container">
            
            <div class="video-container">
                <h1><?php echo $produit['nom']  ?></h1> 
                <video autoplay controls>
                    <source src="<?php echo $produit['video']  ?>" type="video/mp4">
                </video>
            </div>
            <div>
            <p>Description du produit : <?php echo $produit['description']  ?> </p>
            <p>Prix : <?php echo $produit['prix']  ?> DT</p>
            <div class='a'>
                <div class='b'>
                    <input type="text" readonly placeholder="Choisir la taille" class="output">
                    <br>
                    <br>
                    <div class="lists">
                        <div class="item">XS</div>
                        <div class="item">S</div>
                        <div class="item">M</div>
                        <div class="item">L</div>
                        <div class="item">XL</div>
                    </div>

                </div>

            </div>
            <br>
            <br>

          
         <form action="commander.php" method="post">
            <div class="btn">
                <label for="nom">Quantité :</label>
                <input  id="qte" name="qte"  required>
            </div>
            <input type="hidden" value="<?php echo $produit['id_prod']  ?>" name="produit">
            <br> 
            <br>
            <?php if (!$is_logged_in): ?>
                <button id="ajouter-panier" class="btn" onclick="alerter()">Ajouter au panier</button> 
            <?php else: ?>
                <button id="ajouter-panier" class="btn">Ajouter au panier</button>
            <?php endif; ?>
         </form>
        </div>
        </div>
    </section>
<footer class="autrepage">

        <div class="container2">
        <div class="grid-container">
                <div class="grid-item">
                    <h2>Besoin d'aide</h2>
                    <a href="contact.php">Envoyer un email</a>
                </div>
    
                <div class="grid-item">
                    <h2>Cela peut t'intéresser</h2>
                    <a href="produits.php">Robes</a>
                    <a href="produits.php">Vestes</a>
                    <a href="produits.php">Pulls et gilets</a>
                    <a href="produits.php">Baggy jeans</a>
                    <a href="produits.php">Pantalons</a>
                </div>
    
                <div class="grid-item">
                    <h2>Réseaux sociaux</h2>
                    <a href="https://www.facebook.com" target="_blank"><img  src="facebook.png" label="Facebook">Facebook</a>
                    <a href="https://www.instagram.com" target="_blank"><img  src="instagram.png" label="Instagram">Instagram</a>
                </div>
            </div>
        </div>

    
</footer>
<script>
    document.addEventListener("DOMContentLoaded", function() {
    let dropdown_items = document.querySelectorAll('.a .b .lists .item');
    let output = document.querySelector('.a .b .output');
    
    dropdown_items.forEach(item => {
        item.addEventListener('click', function() {
            output.value = item.innerHTML;
        });
    });
});
function alerter(){

alert ("Vous n'êtes pas connecté(e)");
}

</script>


 
</body>
</html>