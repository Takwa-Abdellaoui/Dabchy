<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8', 'root', '');
    } catch (Exception $e) {
        die('Erreur : ' . $e->getMessage());
    }

    $id = $_GET['id'];
    $nom = $_GET['nom'];
    $qte = $_POST['qte'];


   
    $requete = "UPDATE stock SET qte=:qte WHERE id=:id";
    $statement = $db->prepare($requete);
    
    $statement->bindParam(':qte', $qte);
    $statement->bindParam(':id', $id);
    
    $resultat = $statement->execute();

    if ($resultat) {
    
        header('Location: stock.php');
        exit;
    } else {
       
        echo "Erreur lors de la mise à jour du produit.";
    }
}


try {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

$id = $_GET['id'];
// Retrieve product data from the database
$statement = $db->prepare("SELECT * FROM stock WHERE id=:id");
$statement->execute(array(':id' => $id));
$produit = $statement->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification Produit</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom'] . " " . $_SESSION['prenom']; ?></h4>
    </header>
    <div class="container">
        <h1>Modification</h1>
        <form action="<?= $_SERVER['PHP_SELF'] . '?id=' . $id ?>" method="post">
            <div class="form-group">
                <label for="description">Nouvelle Quantité Du <?php echo $_GET['nom'] ; ?> :</label>
                <input  id="qte" name="qte" value="<?= $produit['qte'] ?>" required>
            </div>
    
            <div class="form-group">
                <button type="submit" class="btn">Modifier</button>
                <a href="listeprod.php" class="btn">Retour</a>
            </div>
        </form>
    </div>
</body>

</html>