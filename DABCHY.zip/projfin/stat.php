<?php
include "acessdabchy.php";
session_start();
$data=getdata();  


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
        
</header>
<div >
      <div class="container">
        <h2>Statistiques</h2>
        <a href="admin.php" class="btn">Retour</a>
         
        
      </div>

       <div >
       <div class="container">
        Nombre De Produits:
        <?php echo $data['produits'] ;   ?>
       </div>
       <div class="container">
        Nombre De Clients:
        <?php echo $data['clients'] ;   ?>
       </div>
       <div class="container">
        Nombre De Commandes:
        <?php echo $data['commandes'] ;   ?>
       </div>


</div>        
</div> 
</body>
</html>
