<?php
session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8', 'root', '');
    } catch (Exception $e) {
        die('Erreur : ' . $e->getMessage());
    }

    $id = $_GET['id'];
  
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    $mdp = $_POST['mdp'];


    $requete = "UPDATE admin SET nom=:nom, prenom=:prenom, email=:email, tel=:tel, mdp=:mdp WHERE id_admin=:id";
    $statement = $db->prepare($requete);

    $statement->bindParam(':nom', $nom);
    $statement->bindParam(':prenom', $prenom);
    $statement->bindParam(':email', $email);
    $statement->bindParam(':tel', $tel);
    $statement->bindParam(':mdp', $mdp);
    $statement->bindParam(':id', $id);
    

    $resultat = $statement->execute();

    if ($resultat) {
    
        header('Location: listeadmin.php');
        exit;
    } else {
      
        echo "Erreur lors de la mise à jour .";
    }
}

// If the form is not submitted, retrieve the product data and populate the form fields
try {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

$id = $_GET['id'];
// Retrieve product data from the database
$statement = $db->prepare("SELECT * FROM admin WHERE id_admin=:id");
$statement->execute(array(':id' => $id));
$admin = $statement->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom'] . " " . $_SESSION['prenom']; ?></h4>
    </header>
    <div class="container">
        <h1>Modification</h1>
        <form action="<?= $_SERVER['PHP_SELF'] . '?id=' . $id ?>" method="post">
            <div class="form-group">
                <label for="nom">Nom :</label>
                <input type="text" id="nom" name="nom" value="<?= $admin['nom'] ?>" required>
            </div>
            <div class="form-group">
                <label for="prenom">Prenom :</label>
                <input type="text" id="prenom" name="prenom" value="<?= $admin['prenom'] ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email :</label>
                <input type="text" id="email" name="email" value="<?= $admin['email'] ?>" required>
            </div>
            <div class="form-group">
                <label for="tel">Tel :</label>
                <input type="text" id="tel" name="tel" value="<?= $admin['tel'] ?>" required>
            </div>
            <div class="form-group">
                    <label for="mot_de_passe">Mot de passe :</label>
                    <input type="password" id="mdp" name="mdp" value="<?= $admin['mdp'] ?>" required>
            </div>
                
            <div class="form-group">
                <button type="submit" class="btn">Modifier</button>
                <a href="listeadmin.php" class="btn">Retour</a>
            </div>
        </form>
    </div>
</body>

</html>