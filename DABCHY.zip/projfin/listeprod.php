<?php
include "acessdabchy.php";
session_start();
$produits=getprod();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>
       .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th,
        .table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .table thead th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

      
        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

       

        .btn:hover {
            background-color: red;
        }
        
    </style>
</head>
<body>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
        
</header>
<div >
      <div class="container">
        <h2>Liste Des Produits</h2>
        <a href="admin.php" class="btn">Retour</a>
        <a href="ajoutprod.php" class="btn">Ajouter</a>
      </div>

       <div >
          <table class="table">
          <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nom</th>
      <th scope="col">Description</th>
      <th scope="col">Prix</th>
      <th scope="col">Image</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($produits as $produit){
        print '<tr>
        <th scope="row">'.$produit['id_prod'].'</th>
        <td>'.$produit['nom'].'</td>
        <td>'.$produit['description'].'</td>
        <td>'.$produit['prix'].'</td>
        <td> <div><img src="'.$produit['image'].'"></div> </td>
        <td><a href="modifier.php?id='.$produit['id_prod'].'" class="btn">Modifier</a> 
        <a href="supprimerprod.php?id='.$produit['id_prod'].'" class="btn">Supprimer</a>
      </td>
      </tr>';
    }
    ?>
  </tbody>
</table>       
</div>  
</div> 
</body>
</html>
