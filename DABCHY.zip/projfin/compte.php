<?php
session_start();
if(isset($_SESSION['nom'])){
    header('location:profile.php');

}
include "acessdabchy.php";

if (!empty($_POST)){
    addvis($_POST);
}



?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dabchy - Contact</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Dabchy</h1>
        <nav>
            <ul>
                <li><a href="home.php">Accueil</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="connexion.php">Connexion</a></li>
                <li><a href="compte.php">Compte</a></li>
            </ul>
        </nav>
    </header>
    <section class="contact">
        <div class="container">
            <h2>Créer Compte</h2>
            <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post" class="form">
                <div class="form-group">
                    <label for="nom">Nom de famille :</label>
                    <input type="text" id="nom" name="nom" required>
                </div>
                <div class="form-group">
                    <label for="prenom">Prénom :</label>
                    <input type="text" id="prenom" name="prenom" required>
                </div>
                
                <div class="form-group">
                    <label for="email">E-mail :</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="tel">Numéro de téléphone :</label>
                    <input type="text" id="tel" name="tel" required>
                </div>
                <div class="form-group">
                    <label for="mot_de_passe">Mot de passe :</label>
                    <input type="password" id="mdp" name="mdp" required>
                </div>
                <div >
                    <label for="politique_confidentialite">J'ai lu et j'accepte la politique de confidentialité</label>
                    <input type="checkbox" id="politique_confidentialite" name="politique_confidentialite" required>
                </div>
                <br>
                <div class="form-group">
                    <button type="submit" class="btn">Envoyer</button>
                </div>
            </form>
        </div>
    </section>
    <footer class="autrepage">

        <div class="container2">
            <div class="grid-container">
                <div class="grid-item">
                    <h2>Besoin d'aide</h2>
                    <a href="contact.php">Envoyer un email</a>
                </div>
    
                <div class="grid-item">
                    <h2>Cela peut t'intéresser</h2>
                    <a href="produits.php">Robes</a>
                    <a href="produits.php">Vestes</a>
                    <a href="produits.php">Manteaux</a>
                    <a href="produits.php">Pulls et gilets</a>
                    <a href="produits.php">Baggy jeans</a>
                    <a href="produits.php">Pantalons</a>
                    <a href="produits.php">Jupes et Shorts</a>
                </div>
    
                <div class="grid-item">
                    <h2>Réseaux sociaux</h2>
                    <a href="https://www.facebook.com" target="_blank"><img  src="facebook.png" label="Facebook">Facebook</a>
                    <a href="https://www.instagram.com" target="_blank"><img  src="instagram.png" label="Instagram">Instagram</a>
                </div>
            </div>
        </div>
        <script>
    document.getElementsByClassName("form")[0].addEventListener("submit", function(event) {
        event.preventDefault();
        alert("VOTRE COMPTE A ETE CREE AVEC SUCCES !");
        this.reset();
    });
</script>


    
</footer>
</body>
</html>