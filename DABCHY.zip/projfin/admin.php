<?php
include "acessdabchy.php";
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style1.css">
    <style>
        .background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('test.png.jpeg');
            background-size: cover;
            filter: blur(10px);
            z-index: -1; 
        }

      
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #e3e3e3; 
        }
   
        .admin-panel {
            display: flex;
            gap: 50px;
            margin-top: 250px;
        }
        .panel-item {
            height: 50px;
            width: 130px;
        }
        .panel-item h2 {
            font-size: 24px;
            margin-top: 10px;
            margin-bottom: 15px;
            text-decoration: none;
            color: white;
            text-align: center;
        }
        .panel-item a {
            text-decoration: none;
            text-align: center;
        }
        header {
    background-color: black;
    color: white;
    padding-top: 20px;
    padding-bottom: 20px;
    text-align: center;
    
    width: 100%; 
}

header h1 {
    margin: 0;
}

    </style>
</head>
<body>
<div class="background"></div>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
</header>
<div class="container">
<div class="admin-panel">

      <div class="panel-item">
        <a href="stat.php"><h2>Statistiques</h2></a>
        
      </div>
      <div class="panel-item">
        <a href="listeprod.php"><h2>Produits</h2></a>
        
      </div>
      <div class="panel-item">
        <a href="listepan.php"><h2>Paniers</h2></a>
        
      </div>
      <div class="panel-item">
        
        <a href="listevis.php"><h2>Clients</h2></a>
      </div>
      <div class="panel-item">
        
        <a href="listeadmin.php"><h2>Admins</h2></a>
      </div>
      <div class="panel-item">
        
        <a href="stock.php"><h2>Stocks</h2></a>
      </div>
      <div class="panel-item">
      <a href="deconnexion.php" class="btn"><h2>Deconnexion</h2></a>
        
      </div>
</div>    
</div>   
</body>
</html>