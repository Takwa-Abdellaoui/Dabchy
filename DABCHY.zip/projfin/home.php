<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dabchy - Accueil</title>
    <link rel="stylesheet" href="style.css">

    <style>
   
        .slideshow-container {
            max-width: 2000px;
            position: relative;
            margin: auto;
            height: 800px;
            
            margin-bottom:0px;
        }

        .mySlides {
            display: none;
        }

        .mySlides img {
            width: 100%;
            height: auto;
        }
        .section1 .background {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url('test.png.jpeg');
    filter: blur(10px);
    
    background-position: center;
    
 }
.section1 .content {
    position: relative;
    text-align: center;
    padding: 50px;
}
    </style>
</head>
<body>
    <header>
        <h1>Dabchy</h1>
        <nav>
            <ul>
                <li><a href="home.php">Accueil</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="connexion.php">Connexion</a></li>
                <li><a href="compte.php">Compte</a></li>
                <li><a href="panier.php">Panier</a></li>
            </ul>
        </nav>
    </header>
  

    <section class="section1">
        <div class="background"></div>
        <div class="content">
        <h1>Bienvenue chez Dabchy</h1>
        <h3>Découvrez notre collection de vêtements tendance.</h3>
        <a href="produits.php" class="btn">Voir les produits</a>
        </div>
        
    </section>

    <div class="slideshow-container">
        <div class="mySlides fade">
            <img src="s3.png" alt="Slide 2">
        </div>
        <div class="mySlides fade">
            <img src="s1.png" alt="Slide 1">
        </div>
        <div class="mySlides fade">
            <img src="s2.png" alt="Slide 2">
        </div>
        
        <div class="mySlides fade">
            <img src="s5.png" alt="Slide 2">
        </div>
        <div class="mySlides fade">
            <img src="s4.png" alt="Slide 2">
        </div>
    </div>

    
    <footer class="homepage">
        <p>&copy; 2024 Dabchy. Tous droits réservés.</p>
    </footer>

    <script>
        let slideIndex = 0;
        showSlides();

        function showSlides() {
            let i;
            const slides = document.getElementsByClassName("mySlides");
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            slideIndex++;
            if (slideIndex > slides.length) {
                slideIndex = 1;
            }
            slides[slideIndex - 1].style.display = "block";
            setTimeout(showSlides, 2000);
        }
    </script>
</body>
</html>
