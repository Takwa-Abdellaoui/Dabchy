<?php
include "acessdabchy.php";
session_start();
$admins=getalladmin();  


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>
       .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th,
        .table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

      
        .table thead th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

     
        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

       

        .btn:hover {
            background-color: red;
        }
        

    </style>
</head>
<body>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
        
</header>
<div >
      <div class="container">
        <h2>Liste Des Admins</h2>
        <a href="admin.php" class="btn">Retour</a>
        <a href="ajoutadmin.php" class="btn">Ajouter</a>  
        
      </div>

       <div >
          <table class="table">
          <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Email</th>
      <th scope="col">Tel</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($admins as $a){
        print '<tr>
        <th scope="row">'.$a['id_admin'].'</th>
        <td>'.$a['nom'].'</td>
        <td>'.$a['prenom'].'</td>
        <td>'.$a['email'].'</td>
        <td> '.$a['tel'].' </td>
        <td><a href="supprimeradmin.php?id='.$a['id_admin'].'" class="btn">Supprimer</a>
        <a href="modifieradmin.php?id='.$a['id_admin'].'" class="btn">Modifier</a></td>
      </tr>';     
    }
    ?>
  </tbody>
</table>       
</div>  
</div> 
</body>
</html>
