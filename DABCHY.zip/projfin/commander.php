
<?php
session_start();
if(!isset($_SESSION['nom'])){
    header('location:connexion.php');
    exit();
}


include "acessdabchy.php";
try
{
$db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8','root', '');

}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}

 $visiteur=$_SESSION['id_vis'];
 $id=$_POST['produit'];
$qte=$_POST['qte'];

 $requette="SELECT prix,nom FROM produits WHERE id_prod='$id'";
 $resultat=$db->query($requette);
 $produit=$resultat->fetch();
 $total=$qte * $produit['prix'];
 $date = date("Y-m-d");

 if(!isset($_SESSION['panier'])){
    $_SESSION['panier']=array($visiteur,0,$date,array());

 }
 $_SESSION['panier'][1]+=$total;
$_SESSION['panier'][3][]=array($qte,$total,$date,$id,$produit['nom']);



header('location:panier.php');
?>