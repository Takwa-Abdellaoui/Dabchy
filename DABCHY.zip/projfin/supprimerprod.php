<?php
include "acessdabchy.php";
$id= $_GET['id'];

if(supprod($id)){
    header('location:listeprod.php');
}
?>