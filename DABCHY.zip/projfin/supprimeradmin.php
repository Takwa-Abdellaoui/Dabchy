<?php
include "acessdabchy.php";
$id= $_GET['id'];

if(suppadmin($id)){
    header('location:listeadmin.php');
}
?>