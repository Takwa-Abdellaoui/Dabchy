<?php
include "acessdabchy.php";
session_start();
$stocks=getstock();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>
       .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th,
        .table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        /* Header row styles */
        .table thead th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        /* Alternate row background color */
        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

       

        .btn:hover {
            background-color: red;
        }
        
    </style>
</head>
<body>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
        
</header>
<div >
      <div class="container">
        <h2>Stock Des Produits</h2>
        <a href="admin.php" class="btn">Retour</a>
        
      </div>

       <div >
          <table class="table">
          <thead>
    <tr>
      <th scope="col">ID Stock</th>
      <th scope="col">Nom Du Produit</th>
      <th scope="col">Quantité</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $total=0;
    foreach($stocks as $stock){
        print '<tr>
        <th scope="row">'.$stock['id'].'</th>
        <td>'.$stock['nom'].'</td>
        <td>'.$stock['qte'].'</td>
        <td><a href="modifierstock.php?id='.$stock['id'].'&nom='.$stock['nom'].'" class="btn">Modifier</a> 
        
      </td>
      </tr>';
      $total+=$stock['qte'];
      
    }
    ?>
    <?php echo "total = $total";?> 
  </tbody>
</table>       
</div>  
</div> 
</body>
</html>
