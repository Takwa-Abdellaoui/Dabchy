<?php
include "acessdabchy.php";
session_start();
$paniers=getallpan();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>
       .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th,
        .table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .table thead th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

       

        .btn:hover {
            background-color: red;
        }
       
    </style>
</head>
<body>
<header>
        <h1>Admin Dashboard</h1>
        <h4><?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;    ?></h4>
        
</header>
<div >
      <div class="container">
        <h2>Liste Des Paniers</h2>
        <a href="admin.php" class="btn">Retour</a>
        
      </div>

       <div >
          <table class="table">
          <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Client</th>
      <th scope="col">Tel</th>
      <th scope="col">Total</th>
      <th scope="col">Date</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $i=0;
    foreach($paniers as $panier){
        $i++;
        print '<tr>
        <th scope="row">'.$i.'</th>
        <td>'.$panier['nom'].' '.$panier['prenom'].'</td>
        <td>'.$panier['tel'].'</td>
        <td>'.$panier['total'].'DT'.'</td>
        <td> '.$panier['date'].' </td>
        <td><a href="listecomm.php?id='.$panier['id'].'" class="btn">Afficher</a>
        <a href="validercomm.php?id='.$panier['id'].'" class="btn">Valider</a></td>
      </tr>';
    }
    ?>
  </tbody>
</table>       
</div>  
</div> 
</body>
</html>
