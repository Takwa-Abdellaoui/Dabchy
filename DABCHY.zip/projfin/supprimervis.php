<?php
include "acessdabchy.php";
$id= $_GET['id'];

if(suppvis($id)){
    header('location:listevis.php');
}
?>