<?php
include "acessdabchy.php";
session_start();
try {
    $db = new PDO('mysql:host=localhost;dbname=dabchy;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

$id = $_GET['id'];


$requete = "UPDATE panier  SET etat=1 WHERE id=$id";
$resultat= $db->exec($requete);

if ($resultat) {
    
    header('Location: listepan.php');
    
} 
?>