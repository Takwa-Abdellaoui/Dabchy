<?php
include "acessdabchy.php";
$produits= getprod();



?>




<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dabchy - Produits</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Dabchy</h1>
        <nav>
            <ul>
                <li><a href="home.php">Accueil</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="connexion.php">Connexion</a></li>
                <li><a href="compte.php">Compte</a></li>
                <li><a href="panier.php">Panier</a></li>
            </ul>
        </nav>
    </header>
    
    <div class="photo-grid">
    <?php
    foreach($produits as $produit){
        print' <div class="item"><img src="'.$produit['image'].'" alt="Article 1 Homme">
        <h3>'.$produit['nom'].'</h3>
        <p>'.$produit['prix'].' DT </p>
        <a href="details_produit.php?id='.$produit['id_prod'].'" class="btn">Voir les détails</a>
        </div>';

    }
    ?>
    </div>
    

 <footer class="autrepage">

    <div class="container2">
        <div class="grid-container">
            <div class="grid-item">
                <h2>Besoin d'aide</h2>
                <a href="contact.php">Envoyer un email</a>
            </div>

            <div class="grid-item">
                <h2>Cela peut t'intéresser</h2>
                <a href="produits.php">Robes</a>
                <a href="produits.php">Vestes</a>
                <a href="produits.php">Manteaux</a>
                <a href="produits.php">Pulls et gilets</a>
                <a href="produits.php">Baggy jeans</a>
                <a href="produits.php">Pantalons</a>
                <a href="produits.php">Jupes et Shorts</a>
            </div>

            <div class="grid-item">
                <h2>Réseaux sociaux</h2>
                <a href="https://www.facebook.com" target="_blank"><img  src="facebook.png" label="Facebook">Facebook</a>
                <a href="https://www.instagram.com" target="_blank"><img  src="instagram.png" label="Instagram">Instagram</a>
            </div>
        </div>
    </div>


</footer>
</body>
</html>