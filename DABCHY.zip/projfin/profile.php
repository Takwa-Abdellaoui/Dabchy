
<?php
include "acessdabchy.php";
session_start();
if(!isset($_SESSION['nom'])){
    header('location:connexion.php');

}




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
        <h1>Dabchy</h1>
        <nav>
            <ul>
                <li><a href="home.php">Accueil</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="panier.php">Panier</a></li>
                
                
            </ul>
        </nav>
</header>



<div class="container">
    <h2>Bienvenue <?php echo $_SESSION['nom']." ".$_SESSION['prenom']  ;  ?> dans votre compte</h2>
    <a href="deconnexion.php" class="btn">Deconnexion</a>
</div>
<footer class="autrepage">

    <div class="container2">
        <div class="grid-container">
            <div class="grid-item">
                <h2>Besoin d'aide</h2>
                <a href="contact.php">Envoyer un email</a>
            </div>
    
            <div class="grid-item">
                <h2>Cela peut t'intéresser</h2>
                <a href="produits.php">Robes</a>
                <a href="produits.php">Vestes</a>
                <a href="produits.php">Manteaux</a>
                <a href="produits.php">Pulls et gilets</a>
                <a href="produits.php">Baggy jeans</a>
                <a href="produits.php">Pantalons</a>
                <a href="produits.php">Jupes et Shorts</a>
            </div>
    
            <div class="grid-item">
                <h2>Réseaux sociaux</h2>
                <a href="https://www.facebook.com" target="_blank"><img  src="facebook.png" label="Facebook">Facebook</a>
                <a href="https://www.instagram.com" target="_blank"><img  src="instagram.png" label="Instagram">Instagram</a>
            </div>
        </div>
    </div>

    
</footer>
    
</body>
</html>