<?php
session_start();
if(isset($_SESSION['nom'])){
    header('location:profile.php');
}

include "acessdabchy.php";

if (!empty($_POST)){
    $user1=connectvis($_POST);
    $user2=connectadmin($_POST);

    if($user1 != false){
        $_SESSION['id_vis']=$user1['id_vis'];
        $_SESSION['email']=$user1['email'];
        $_SESSION['nom']=$user1['nom'];
        $_SESSION['prenom']=$user1['prenom'];
        $_SESSION['tel']=$user1['tel'];
        $_SESSION['mdp']=$user1['mdp'];
        header('location:profile.php');
    } elseif ($user2 != false) {
        $_SESSION['email']=$user2['email'];
        $_SESSION['nom']=$user2['nom'];
        $_SESSION['prenom']=$user2['prenom'];
        $_SESSION['tel']=$user2['tel'];
        $_SESSION['mdp']=$user2['mdp'];
        header('location:admin.php');
    } else {
        echo "<script>alert('Incorrect email or password. Please try again.');</script>";
    }
}
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dabchy-connexion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Dabchy</h1>
        <nav>
            <ul>
                <li><a href="home.php">Accueil</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="connexion.php">Connexion</a></li>
                <li><a href="compte.php">Compte</a></li>
                <li><a href="panier.php">Panier</a></li>
                
            </ul>
        </nav>
    </header>

    <section class="contact">
        <div class="container">
            <h2>Connectez-Vous</h2>
            <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                <div class="form-group">
                    <label for="email">E-mail :</label>
                    <input type="text" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="mot_de_passe">Mot de passe :</label>
                    <input type="password" id="mdp" name="mdp" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">connexion</button>
                </div>
            </form>    
        </div>
    </section>                    









    <footer class="autrepage">

        <div class="container2">
            <div class="grid-container">
                <div class="grid-item">
                    <h2>Besoin d'aide</h2>
                    <a href="contact.php">Envoyer un email</a>
                </div>
    
                <div class="grid-item">
                    <h2>Cela peut t'intéresser</h2>
                    <a href="produits.php">Robes</a>
                    <a href="produits.php">Vestes</a>
                    <a href="produits.php">Manteaux</a>
                    <a href="produits.php">Pulls et gilets</a>
                    <a href="produits.php">Baggy jeans</a>
                    <a href="produits.php">Pantalons</a>
                    <a href="produits.php">Jupes et Shorts</a>
                </div>
    
                <div class="grid-item">
                    <h2>Réseaux sociaux</h2>
                    <a href="https://www.facebook.com" target="_blank"><img  src="facebook.png" label="Facebook">Facebook</a>
                    <a href="https://www.instagram.com" target="_blank"><img  src="instagram.png" label="Instagram">Instagram</a>
                </div>
            </div>
        </div>

    
    </footer>
</body>

</html>